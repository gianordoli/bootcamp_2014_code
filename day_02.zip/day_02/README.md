## PARSONS THE NEW SCHOOL FOR DESIGN
## Summer 2014 Bootcamp Code Syllabus
-------------------------------------------------------------------

### DAY 2
Using Variables

##Key Concepts
* Defining variables
* Basic data types
* Declaring vs. initializing variables
* Naming conventions (camelCase)
* Basic system variables
* Basic operators
* Intro to debugging
* Intro to interaction
* Saving images
* ProcessingJS for openProcessing
  
##Homework:
Capture a procedural image - 
* Parameterize day 1 homework - use variables and operators to change the sketch in some way over time
* Try using system variables too

##References:
* N/A
